dwlzxxyplldlldxdptd.exe
--------------------------------
( made by le thy     )
--------------------------------
this malware need install msvcr120.dll
os : winxp (yes compilate)/ win7/win8.1 (end of life in jan 10 2023)/win10/win11
date: dec 17 2023 (chirstmas eve)
--- for skidder --
n17pro3426 stoleof name
this garbage malware 
GRRRRRRRRRRRRR